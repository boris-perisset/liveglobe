// maplibre-gl 6 liefert kein Default-Export mehr – alles kommt benannt.
import {
  AttributionControl,
  type GeoJSONSource,
  MapLibreMap,
  Marker,
  NavigationControl,
} from "maplibre-gl";
import type { CategoryDef, CategoryId, Cluster } from "../types";
import { ladeStil, PALETTE } from "./style";

/**
 * Ab dieser Pin-Zahl wechseln wir von DOM-Markern auf eine GPU-Ebene.
 * DOM-Marker sind bequem (echtes HTML, CSS, Fokus), skalieren aber nicht:
 * Jeder kostet ein Element, das bei jeder Kamerabewegung neu positioniert wird.
 */
const MARKER_LIMIT = 400;

const PUNKT_QUELLE = "meldungen";
const PUNKT_EBENE = "meldungen-punkte";

export interface MapOptions {
  container: HTMLElement;
  categories: CategoryDef[];
  onPinClick: (cluster: Cluster) => void;
  onZoomChange: (zoom: number) => void;
}

export class NewsMap {
  private map: MapLibreMap | null = null;
  private colorByCategory: Map<CategoryId, string>;
  private onPinClick: (c: Cluster) => void;
  private onZoomChange: (z: number) => void;

  private clusters: Cluster[] = [];
  private marker: Marker[] = [];
  private bereit = false;
  private drehen = true;
  private drehTimer: number | undefined;

  constructor(private opts: MapOptions) {
    this.onPinClick = opts.onPinClick;
    this.onZoomChange = opts.onZoomChange;
    this.colorByCategory = new Map(
      opts.categories.map((c) => [c.id, c.color] as [CategoryId, string]),
    );
    void this.starten();
  }

  private async starten() {
    const style = await ladeStil();

    const map = new MapLibreMap({
      container: this.opts.container,
      style,
      center: [10, 25],
      zoom: 1.4,
      minZoom: 0.6,
      maxZoom: 14,
      attributionControl: false,
      // Der Globus lebt von der Aufsicht; Neigen würde nur verwirren.
      pitchWithRotate: false,
      dragRotate: false,
    });
    this.map = map;

    map.addControl(
      new AttributionControl({
        compact: true,
        customAttribution:
          '<a href="https://openfreemap.org" target="_blank" rel="noopener">OpenFreeMap</a> · ' +
          "© OpenMapTiles · Daten © OpenStreetMap-Mitwirkende · " +
          'Meldungen: <a href="https://www.gdeltproject.org/" target="_blank" rel="noopener">The GDELT Project</a>',
      }),
      "bottom-right",
    );
    map.addControl(
      new NavigationControl({ showCompass: false }),
      "bottom-right",
    );

    map.on("load", () => {
      this.bereit = true;
      this.punktEbeneAnlegen();
      this.zeichnen();
    });

    map.on("zoomend", () => this.onZoomChange(this.zoom));
    map.on("moveend", () => this.onZoomChange(this.zoom));

    // Eigendrehung als erster Eindruck – pausiert, sobald jemand die Karte anfasst,
    // und läuft nach längerer Ruhe wieder an.
    for (const ev of ["mousedown", "touchstart", "wheel", "mousemove"] as const) {
      map.on(ev, () => this.drehenPausieren());
    }
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      this.drehen = false;
    }
    this.drehschleife();
  }

  // ---------------------------------------------------------------- Drehung
  private drehenPausieren() {
    this.drehen = false;
    window.clearTimeout(this.drehTimer);
    this.drehTimer = window.setTimeout(() => {
      this.drehen = true;
    }, 20_000);
  }

  private drehschleife() {
    let zuletzt = performance.now();
    const schritt = (jetzt: number) => {
      const dt = (jetzt - zuletzt) / 1000;
      zuletzt = jetzt;
      // Nur weit draussen drehen – beim Hineinzoomen wäre es störend.
      if (this.drehen && this.map && this.map.getZoom() < 2.5) {
        const c = this.map.getCenter();
        this.map.setCenter([c.lng + 2.5 * dt, c.lat]);
      }
      requestAnimationFrame(schritt);
    };
    requestAnimationFrame(schritt);
  }

  // ---------------------------------------------------------------- Pins
  private punktEbeneAnlegen() {
    const map = this.map!;
    if (map.getSource(PUNKT_QUELLE)) return;

    map.addSource(PUNKT_QUELLE, {
      type: "geojson",
      data: { type: "FeatureCollection", features: [] },
    });
    map.addLayer({
      id: PUNKT_EBENE,
      type: "circle",
      source: PUNKT_QUELLE,
      paint: {
        "circle-color": ["get", "farbe"],
        "circle-radius": ["interpolate", ["linear"], ["get", "n"], 1, 4, 30, 11],
        "circle-stroke-width": 1.2,
        "circle-stroke-color": PALETTE.halo,
        "circle-opacity": 0.92,
      },
    });

    map.on("click", PUNKT_EBENE, (e) => {
      const f = e.features?.[0];
      if (!f) return;
      const i = Number(f.properties?.index);
      const c = this.clusters[i];
      if (c) this.onPinClick(c);
    });
    map.on("mouseenter", PUNKT_EBENE, () => {
      map.getCanvas().style.cursor = "pointer";
    });
    map.on("mouseleave", PUNKT_EBENE, () => {
      map.getCanvas().style.cursor = "";
    });
  }

  setClusters(clusters: Cluster[]) {
    this.clusters = clusters;
    if (this.bereit) this.zeichnen();
  }

  private zeichnen() {
    const map = this.map;
    if (!map) return;

    for (const m of this.marker) m.remove();
    this.marker = [];

    const vieleMeldungen = this.clusters.length > MARKER_LIMIT;

    const quelle = map.getSource(PUNKT_QUELLE) as GeoJSONSource | undefined;
    quelle?.setData({
      type: "FeatureCollection",
      features: vieleMeldungen
        ? this.clusters.map((c, index) => ({
          type: "Feature" as const,
          geometry: { type: "Point" as const, coordinates: [c.lon, c.lat] },
          properties: { index, n: c.n, farbe: this.colorFor(c.top_category) },
        }))
        : [],
    });

    if (vieleMeldungen) return;

    for (const c of this.clusters) {
      this.marker.push(
        new Marker({ element: this.makePin(c), anchor: "bottom" })
          .setLngLat([c.lon, c.lat])
          .addTo(map),
      );
    }
  }

  private makePin(c: Cluster): HTMLElement {
    const el = document.createElement("button");
    el.className = "pin";
    el.type = "button";
    el.style.setProperty("--pin-color", this.colorFor(c.top_category));
    el.setAttribute(
      "aria-label",
      `${c.n} ${c.n === 1 ? "Meldung" : "Meldungen"} – ${c.location_name}`,
    );
    el.title = c.location_name;
    el.innerHTML =
      `<span class="pin__head">${c.n > 1 ? c.n : ""}</span><span class="pin__tail"></span>`;
    el.addEventListener("click", (e) => {
      e.stopPropagation();
      this.onPinClick(c);
    });
    return el;
  }

  private colorFor(cat: CategoryId): string {
    return this.colorByCategory.get(cat) ?? "#7B808A";
  }

  // ---------------------------------------------------------------- Kamera
  /**
   * Zoomstufe für die Datenabfrage.
   *
   * Die Cluster-Funktion in der Datenbank rechnet mit 0–8 und leitet daraus die
   * Rasterweite ab. MapLibres Zoom passt dazu unmittelbar; wir kappen nur oben,
   * damit die Rasterzellen nicht kleiner werden als sinnvoll.
   */
  get zoom(): number {
    return Math.max(0, Math.min(8, this.map?.getZoom() ?? 1.4));
  }

  flyTo(lat: number, lon: number, _altitude = 0.8) {
    this.drehenPausieren();
    this.map?.flyTo({ center: [lon, lat], zoom: Math.max(this.map.getZoom(), 5), duration: 900 });
  }

  resize() {
    this.map?.resize();
  }
}
